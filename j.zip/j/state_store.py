import sys
import sqlite3
import threading
from collections import deque
from pathlib import Path
from typing import Optional
from datetime import datetime, timezone, timedelta

sys.path.insert(0, str(Path(__file__).parent))

from config import (
    SQLITE_PATH,
    SQLITE_SCHEMA,
    DEDUP_WINDOW_SIZE,
    NOMINAL_CAPACITY,
    SOH_ZONES,
    SOH_INTERVENTION_PCT,
)
from schemas import (
    GoldVehicleUpdate,
    SessionCompleted,
    ProducerCheckpoint,
    PipelineMetricsEvent,
    DeadLetterEvent,
    utc_now_iso,
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class StateStore:
    _MAINTENANCE_EVERY  = 5000
    _CHECKPOINT_EVERY   = 5

    def __init__(self, db_path: Path = SQLITE_PATH):
        self._db_path           = db_path
        self._local             = threading.local()
        self._write_lock        = threading.Lock()
        self._dedup_lock        = threading.Lock()
        self._write_counter     = 0
        self._checkpoint_counter= 0

        # In-memory dedup sets per stage (rolling window)
        self._dedup: dict[str, deque] = {}
        self._dedup_sets: dict[str, set] = {}

    def _conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(
                str(self._db_path),
                check_same_thread=False,
                timeout=10.0,
            )
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return self._local.conn

    def init(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._write_lock:
            conn = self._conn()
            for stmt in SQLITE_SCHEMA.split(";"):
                stmt = stmt.strip()
                if stmt:
                    conn.execute(stmt)
            conn.commit()
            for col, defn in [
                ("lower_bound_json",  "TEXT"),
                ("upper_bound_json",  "TEXT"),
                ("is_accelerating",   "INTEGER NOT NULL DEFAULT 0"),
            ]:
                try:
                    conn.execute(f"ALTER TABLE vehicle_projection ADD COLUMN {col} {defn}")
                    conn.commit()
                except Exception:
                    pass

    def close(self) -> None:
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None

    def _run_maintenance(self) -> None:
        with self._write_lock:
            conn = self._conn()
            conn.execute(
                "DELETE FROM processed_events WHERE rowid IN "
                "(SELECT rowid FROM processed_events "
                " WHERE processed_at < datetime('now', '-1 hour') LIMIT 5000)"
            )
            conn.execute(
                "DELETE FROM pipeline_metrics WHERE id NOT IN "
                "(SELECT id FROM pipeline_metrics ORDER BY ts DESC LIMIT 500)"
            )
            conn.execute(
                "DELETE FROM dead_letter WHERE id NOT IN "
                "(SELECT id FROM dead_letter ORDER BY ts DESC LIMIT 500)"
            )
            conn.commit()

        self._checkpoint_counter += 1
        if self._checkpoint_counter >= self._CHECKPOINT_EVERY:
            self._checkpoint_counter = 0
            self._conn().execute("PRAGMA wal_checkpoint(PASSIVE)")

    def is_duplicate(self, event_id: str, stage: str) -> bool:
        with self._dedup_lock:
            s = self._dedup_sets.get(stage)
            if s and event_id in s:
                return True

        row = self._conn().execute(
            "SELECT 1 FROM processed_events WHERE event_id=? AND stage=? LIMIT 1",
            (event_id, stage),
        ).fetchone()
        return row is not None

    def mark_processed(self, event_id: str, stage: str) -> None:
        with self._dedup_lock:
            if stage not in self._dedup:
                self._dedup[stage]      = deque(maxlen=DEDUP_WINDOW_SIZE)
                self._dedup_sets[stage] = set()
            dq = self._dedup[stage]
            if len(dq) == dq.maxlen:
                oldest = dq[0]
                self._dedup_sets[stage].discard(oldest)
            dq.append(event_id)
            self._dedup_sets[stage].add(event_id)

        with self._write_lock:
            self._conn().execute(
                "INSERT OR IGNORE INTO processed_events(event_id, stage, processed_at) VALUES(?,?,?)",
                (event_id, stage, _utc_now()),
            )
            self._conn().commit()

        self._write_counter += 1
        if self._write_counter >= self._MAINTENANCE_EVERY:
            self._write_counter = 0
            self._run_maintenance()

    def upsert_vehicle_state(self, upd: GoldVehicleUpdate) -> None:
        sql = """
        INSERT INTO vehicle_state
            (veh_key, dataset_name, car_id, fault_label, split,
             status, vehicle_fault_score, alarm, soh_pct, soh_zone,
             capacity_ah, capacity_source, risk_score, risk_rank,
             rul_km, mileage_km, total_sessions, current_session_id,
             last_session_score, last_updated, created_at)
        VALUES
            (?,?,?,?,?,
             'idle',?,?,?,?,
             ?,?,?,?,
             ?,?,?,?,
             ?,?,?)
        ON CONFLICT(veh_key) DO UPDATE SET
            -- NOTE: status is intentionally NOT updated here.
            -- set_vehicle_status() is the sole owner of the status column.
            -- Inserting a new vehicle defaults to 'idle'; live status is
            -- managed by the gold consumer after every upsert.
            vehicle_fault_score= excluded.vehicle_fault_score,
            alarm              = excluded.alarm,
            soh_pct            = excluded.soh_pct,
            soh_zone           = excluded.soh_zone,
            capacity_ah        = excluded.capacity_ah,
            capacity_source    = excluded.capacity_source,
            risk_score         = excluded.risk_score,
            risk_rank          = excluded.risk_rank,
            rul_km             = excluded.rul_km,
            mileage_km         = excluded.mileage_km,
            total_sessions     = (SELECT COUNT(*) FROM session_history WHERE veh_key = excluded.veh_key),
            current_session_id = excluded.current_session_id,
            last_session_score = excluded.last_session_score,
            last_updated       = excluded.last_updated
        """
        veh_key = f"{upd.dataset_name}:{upd.car_id}"
        split   = "test" if upd.fault_label >= 0 else "unlabeled"
        now     = _utc_now()
        with self._write_lock:
            self._conn().execute(sql, (
                veh_key, upd.dataset_name, upd.car_id, upd.fault_label, split,
                round(upd.vehicle_fault_score, 6), int(upd.alarm),
                round(upd.soh_pct, 4) if upd.soh_pct is not None else None,
                upd.soh_zone,
                round(upd.capacity_ah, 4), upd.capacity_source,
                round(upd.risk_score, 6),
                upd.risk_rank,
                round(upd.rul_km, 2) if upd.rul_km is not None else None,
                round(upd.mileage_km, 2),
                upd.total_sessions,
                upd.current_session_id,
                round(upd.last_session_score, 6),
                upd.last_updated,
                now,
            ))
            self._conn().commit()

    def set_vehicle_status(self, veh_key: str, status: str) -> None:
        with self._write_lock:
            self._conn().execute(
                "UPDATE vehicle_state SET status=?, last_updated=? WHERE veh_key=?",
                (status, _utc_now(), veh_key),
            )
            self._conn().commit()

    def get_vehicle_state(self, veh_key: str) -> Optional[dict]:
        row = self._conn().execute(
            "SELECT * FROM vehicle_state WHERE veh_key=?", (veh_key,)
        ).fetchone()
        return dict(row) if row else None

    def get_all_vehicles(self) -> list[dict]:
        from datetime import datetime, timezone, timedelta
        _cutoff = (datetime.now(timezone.utc) - timedelta(seconds=30)).isoformat()
        
        # We join with producer_checkpoint to get the true real-time charging status.
        # Otherwise, the UI would see 0 charging vehicles for ~12 seconds while
        # waiting for the Silver consumer to buffer its first 128-step chunk and
        # pass it to Gold.
        query = """
            SELECT 
                v.*,
                COALESCE(
                    (SELECT p.status FROM producer_checkpoint p 
                     WHERE p.vehicle_id = v.veh_key AND p.saved_at >= ?
                     ORDER BY p.saved_at DESC LIMIT 1),
                    v.status
                ) as live_status,
                COALESCE(
                    (SELECT p.session_id FROM producer_checkpoint p 
                     WHERE p.vehicle_id = v.veh_key AND p.status = 'charging' AND p.saved_at >= ?
                     ORDER BY p.saved_at DESC LIMIT 1),
                    v.current_session_id
                ) as live_session_id
            FROM vehicle_state v
            ORDER BY v.risk_score DESC NULLS LAST
        """
        rows = self._conn().execute(query, (_cutoff, _cutoff)).fetchall()
        
        results = []
        for r in rows:
            d = dict(r)
            d['status'] = d['live_status']
            d['current_session_id'] = d['live_session_id']
            del d['live_status']
            del d['live_session_id']
            results.append(d)
        return results

    def get_fleet_summary(self) -> dict:
        """Return a fully-enriched fleet summary used by both the HTTP
        endpoint and the WebSocket broadcast loop.  Computing everything
        here in one place guarantees both consumers see the same values."""
        conn = self._conn()
        total    = conn.execute("SELECT COUNT(*) FROM vehicle_state").fetchone()[0]
        alarms   = conn.execute("SELECT COUNT(*) FROM vehicle_state WHERE alarm=1").fetchone()[0]
        # Read live charging count from producer_checkpoint — this is the
        # authoritative source because the producer writes status='charging'
        # every ~16ms per active vehicle (10 steps × 100ms / 60× speed).
        # We use a 30-second recency window on saved_at to exclude stale
        # 'charging' rows left over from previous runs that did not cleanly
        # reset their checkpoints on shutdown. Any checkpoint not refreshed
        # in 30 s belongs to a producer that is no longer running.
        # This caps the count correctly at MAX_CONCURRENT_VEHICLES (40).
        _cutoff = (datetime.now(timezone.utc) - timedelta(seconds=30)).isoformat()
        charging = conn.execute(
            "SELECT COUNT(*) FROM producer_checkpoint "
            "WHERE status='charging' AND saved_at >= ?",
            (_cutoff,),
        ).fetchone()[0]
        avg_soh  = conn.execute("SELECT AVG(soh_pct)     FROM vehicle_state WHERE soh_pct     IS NOT NULL").fetchone()[0]
        avg_risk = conn.execute("SELECT AVG(risk_score)  FROM vehicle_state WHERE risk_score  IS NOT NULL").fetchone()[0]
        avg_cap  = conn.execute("SELECT AVG(capacity_ah) FROM vehicle_state WHERE capacity_ah IS NOT NULL").fetchone()[0]

        # Zone and dataset distributions — processed vehicles only.
        # Seeded-but-unprocessed vehicles (capacity_source='nominal') have
        # no real soh_zone, so including them would pollute the chart with
        # an 'Unknown' bucket that carries no analytical meaning.
        # total_vehicles above intentionally counts ALL vehicles (fleet size).
        rows = conn.execute(
            "SELECT soh_zone, dataset_name FROM vehicle_state "
            "WHERE capacity_source != 'nominal'"
        ).fetchall()
        zone_dist: dict = {}
        ds_dist:   dict = {}
        for r in rows:
            z = r[0] or "Unknown"
            d = r[1] or "unknown"
            zone_dist[z] = zone_dist.get(z, 0) + 1
            ds_dist[d]   = ds_dist.get(d,   0) + 1

        return {
            "total_vehicles":       total,
            "active_alarms":        alarms,
            "charging_now":         charging,
            "avg_soh_pct":          round(avg_soh,  2) if avg_soh  is not None else None,
            "avg_risk_score":       round(avg_risk, 4) if avg_risk is not None else None,
            "avg_capacity_ah":      round(avg_cap,  3) if avg_cap  is not None else None,
            "zone_distribution":    zone_dist,
            "dataset_distribution": ds_dist,
        }

    def seed_vehicle_registry(self, records: list[dict]) -> None:
        """Pre-populate vehicle_state with nominal defaults for every known
        vehicle so that total_vehicles reflects the full fleet immediately,
        even before those vehicles have been processed by the gold consumer.

        Uses INSERT OR IGNORE so that any existing gold-computed rows are
        never overwritten.
        """
        sql = """
        INSERT OR IGNORE INTO vehicle_state
            (veh_key, dataset_name, car_id, fault_label, split,
             status, capacity_ah, capacity_source,
             mileage_km, total_sessions, last_updated, created_at)
        VALUES (?,?,?,?,?, 'idle',?,?, 0.0, 0, ?,?)
        """
        now = _utc_now()
        with self._write_lock:
            for r in records:
                nom_cap = NOMINAL_CAPACITY.get(r["dataset_name"], 43.0)
                self._conn().execute(sql, (
                    r["vehicle_id"],
                    r["dataset_name"],
                    r["car_id"],
                    r["fault_label"],
                    r["split"],
                    nom_cap,
                    "nominal",
                    now,
                    now,
                ))
            self._conn().commit()

    def update_risk_ranks(self) -> None:
        with self._write_lock:
            self._conn().execute("""
                UPDATE vehicle_state
                SET risk_rank = (
                    SELECT rk FROM (
                        SELECT veh_key,
                               ROW_NUMBER() OVER (ORDER BY risk_score DESC NULLS LAST) AS rk
                        FROM vehicle_state
                    ) ranked
                    WHERE ranked.veh_key = vehicle_state.veh_key
                )
            """)
            self._conn().commit()

    def get_top_risk_vehicles(self, limit: int = 10) -> list[dict]:
        _cutoff = (datetime.now(timezone.utc) - timedelta(seconds=30)).isoformat()
        query = """
            SELECT
                v.*,
                COALESCE(
                    (SELECT p.status FROM producer_checkpoint p
                     WHERE p.vehicle_id = v.veh_key AND p.saved_at >= ?
                     ORDER BY p.saved_at DESC LIMIT 1),
                    v.status
                ) as live_status,
                COALESCE(
                    (SELECT p.session_id FROM producer_checkpoint p
                     WHERE p.vehicle_id = v.veh_key AND p.status = 'charging' AND p.saved_at >= ?
                     ORDER BY p.saved_at DESC LIMIT 1),
                    v.current_session_id
                ) as live_session_id
            FROM vehicle_state v
            WHERE v.risk_score IS NOT NULL
            ORDER BY v.risk_score DESC
            LIMIT ?
        """
        rows = self._conn().execute(query, (_cutoff, _cutoff, limit)).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            d['status'] = d['live_status']
            d['current_session_id'] = d['live_session_id']
            del d['live_status']
            del d['live_session_id']
            results.append(d)
        return results

    def insert_session(self, sc: SessionCompleted, first_event_id: str = None) -> None:
        sql = """
        INSERT INTO session_history
            (veh_key, charge_segment, first_event_id, mileage, session_score,
             capacity_pred, capacity_pred_smooth, capacity_true, fault_label,
             n_chunks_scored, alarm_triggered, session_start_ts, session_end_ts)
        VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?,?)
        ON CONFLICT(veh_key, charge_segment) DO UPDATE SET
            session_score    = excluded.session_score,
            capacity_pred    = excluded.capacity_pred,
            n_chunks_scored  = excluded.n_chunks_scored,
            alarm_triggered  = excluded.alarm_triggered,
            session_end_ts   = excluded.session_end_ts
        """
        veh_key = f"{sc.dataset_name}:{sc.car_id}"
        with self._write_lock:
            self._conn().execute(sql, (
                veh_key,
                sc.session_id,
                first_event_id,
                round(sc.mileage, 2),
                round(sc.final_session_score, 6),
                # capacity_pred: use LSTM live estimate if available; else capacity_pred_smooth
                round(sc.capacity_pred_smooth, 4),
                round(sc.capacity_pred_smooth, 4),
                round(sc.capacity_true, 4) if sc.capacity_true is not None else None,
                sc.fault_label,
                sc.n_chunks_scored,
                int(sc.alarm_triggered),
                sc.session_start_ts,
                sc.session_end_ts,
            ))
            self._conn().commit()

    def get_session_history(self, veh_key: str, limit: int = 200) -> list[dict]:
        rows = self._conn().execute(
            """SELECT * FROM session_history
               WHERE veh_key=?
               ORDER BY charge_segment DESC
               LIMIT ?""",
            (veh_key, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_recent_sessions(self, limit: int = 50) -> list[dict]:
        rows = self._conn().execute(
            """SELECT * FROM session_history
               ORDER BY session_end_ts DESC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]

    def save_checkpoint(self, cp: ProducerCheckpoint) -> None:
        sql = """
        INSERT INTO producer_checkpoint
            (vehicle_id, session_id, step_index, status, idle_until_ts, saved_at)
        VALUES (?,?,?,?,?,?)
        ON CONFLICT(vehicle_id) DO UPDATE SET
            session_id    = excluded.session_id,
            step_index    = excluded.step_index,
            status        = excluded.status,
            idle_until_ts = excluded.idle_until_ts,
            saved_at      = excluded.saved_at
        """
        with self._write_lock:
            self._conn().execute(sql, (
                cp.vehicle_id, cp.session_id, cp.step_index,
                cp.status, cp.idle_until_ts, cp.saved_at,
            ))
            self._conn().commit()

    def load_checkpoint(self, vehicle_id: str) -> Optional[ProducerCheckpoint]:
        row = self._conn().execute(
            "SELECT * FROM producer_checkpoint WHERE vehicle_id=?", (vehicle_id,)
        ).fetchone()
        if not row:
            return None
        return ProducerCheckpoint(
            vehicle_id    = row["vehicle_id"],
            session_id    = row["session_id"],
            step_index    = row["step_index"],
            status        = row["status"],
            idle_until_ts = row["idle_until_ts"],
            saved_at      = row["saved_at"],
        )

    def load_all_checkpoints(self) -> dict[str, ProducerCheckpoint]:
        rows = self._conn().execute("SELECT * FROM producer_checkpoint").fetchall()
        return {
            row["vehicle_id"]: ProducerCheckpoint(
                vehicle_id    = row["vehicle_id"],
                session_id    = row["session_id"],
                step_index    = row["step_index"],
                status        = row["status"],
                idle_until_ts = row["idle_until_ts"],
                saved_at      = row["saved_at"],
            )
            for row in rows
        }

    def clear_checkpoints(self) -> None:
        with self._write_lock:
            self._conn().execute("DELETE FROM producer_checkpoint")
            self._conn().commit()

    def seed_producer_checkpoints(self, last_sessions: dict[str, int]) -> None:
        now = _utc_now()
        with self._write_lock:
            for vehicle_id, session_id in last_sessions.items():
                self._conn().execute(
                    """INSERT OR REPLACE INTO producer_checkpoint
                       (vehicle_id, session_id, step_index, status, idle_until_ts, saved_at)
                       VALUES (?, ?, 127, 'idle', NULL, ?)""",
                    (vehicle_id, session_id, now),
                )
            self._conn().commit()

    def write_pipeline_metrics(self, evt: PipelineMetricsEvent) -> None:
        sql = """
        INSERT INTO pipeline_metrics
            (ts, stage, messages_in, messages_out, messages_rejected,
             messages_duplicate, avg_latency_ms, p99_latency_ms, throughput_per_sec)
        VALUES (?,?,?,?,?,?,?,?,?)
        """
        with self._write_lock:
            self._conn().execute(sql, (
                evt.ts, evt.stage, evt.messages_in, evt.messages_out,
                evt.messages_rejected, evt.messages_duplicate,
                evt.avg_latency_ms, evt.p99_latency_ms, evt.throughput_per_sec,
            ))
            self._conn().commit()

    def get_pipeline_metrics(self, stage: str = None, limit: int = 100) -> list[dict]:
        if stage:
            rows = self._conn().execute(
                "SELECT * FROM pipeline_metrics WHERE stage=? ORDER BY ts DESC LIMIT ?",
                (stage, limit),
            ).fetchall()
        else:
            rows = self._conn().execute(
                "SELECT * FROM pipeline_metrics ORDER BY ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_latest_metrics_per_stage(self) -> dict:
        stages = ["bronze", "silver", "gold"]
        result = {}
        for stage in stages:
            row = self._conn().execute(
                """SELECT * FROM pipeline_metrics WHERE stage=?
                   ORDER BY ts DESC LIMIT 1""",
                (stage,),
            ).fetchone()
            result[stage] = dict(row) if row else None
        return result

    def write_dead_letter(self, evt: DeadLetterEvent) -> None:
        sql = """
        INSERT INTO dead_letter
            (ts, topic, vehicle_id, session_id, step_index, rejection_reason, raw_payload)
        VALUES (?,?,?,?,?,?,?)
        """
        with self._write_lock:
            self._conn().execute(sql, (
                evt.ts, evt.topic, evt.vehicle_id, evt.session_id,
                evt.step_index, evt.rejection_reason, evt.raw_payload,
            ))
            self._conn().commit()

    def get_dead_letters(self, limit: int = 50) -> list[dict]:
        rows = self._conn().execute(
            "SELECT * FROM dead_letter ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_active_alarms(self) -> list[dict]:
        rows = self._conn().execute(
            """SELECT * FROM vehicle_state WHERE alarm=1
               ORDER BY risk_score DESC NULLS LAST"""
        ).fetchall()
        return [dict(r) for r in rows]

    def acknowledge_alarm(self, veh_key: str) -> None:
        with self._write_lock:
            self._conn().execute(
                "UPDATE vehicle_state SET alarm=0, last_updated=? WHERE veh_key=?",
                (_utc_now(), veh_key),
            )
            self._conn().commit()


    # ------------------------------------------------------------------ #
    #  Projection methods (vehicle_projection table)                       #
    # ------------------------------------------------------------------ #

    def get_all_sessions_for_projection(self, veh_key: str) -> list[dict]:
        """Return all sessions for a vehicle ordered by mileage ASC.
        Used by the projection service to fit the decay curve."""
        rows = self._conn().execute(
            """
            SELECT mileage, capacity_pred_smooth, charge_segment
            FROM   session_history
            WHERE  veh_key = ?
              AND  mileage IS NOT NULL
              AND  capacity_pred_smooth IS NOT NULL
            ORDER BY mileage ASC
            """,
            (veh_key,),
        ).fetchall()
        return [dict(r) for r in rows]

    def upsert_vehicle_projection(self, veh_key: str, data: dict) -> None:
        """Insert or replace the projection result for a vehicle."""
        sql = """
        INSERT OR REPLACE INTO vehicle_projection
            (veh_key, dataset_name, computed_at, n_sessions_used, last_session_id,
             current_mileage, current_capacity, lambda_decay, c0_intercept,
             rul_km, intervention_mileage, r_squared, confidence, curve_points_json,
             lower_bound_json, upper_bound_json, is_accelerating)
        VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?,?,?, ?,?,?)
        """
        with self._write_lock:
            self._conn().execute(sql, (
                veh_key,
                data["dataset_name"],
                data["computed_at"],
                data["n_sessions_used"],
                data["last_session_id"],
                data["current_mileage"],
                data["current_capacity"],
                data["lambda_decay"],
                data["c0_intercept"],
                data.get("rul_km"),
                data.get("intervention_mileage"),
                data["r_squared"],
                data["confidence"],
                data["curve_points_json"],
                data.get("lower_bound_json"),
                data.get("upper_bound_json"),
                int(data.get("is_accelerating", 0)),
            ))
            self._conn().commit()

    def get_vehicle_projection(self, veh_key: str) -> Optional[dict]:
        """Return the stored projection for a vehicle, or None."""
        row = self._conn().execute(
            "SELECT * FROM vehicle_projection WHERE veh_key = ?",
            (veh_key,),
        ).fetchone()
        return dict(row) if row else None

    def get_vehicles_needing_projection(
        self,
        min_sessions:  int = 20,
        every_n:       int = 25,
    ) -> list[dict]:
        """
        Returns vehicles that need a projection recomputed.
        Criteria:
          - Have >= min_sessions total sessions with valid mileage+capacity
          - AND either:
            (a) have no projection yet, OR
            (b) their max charge_segment exceeds last_session_id by >= every_n
        Returns list of dicts with keys: veh_key, dataset_name, total_valid_sessions,
        last_session_id (from projection table, or 0 if none).
        """
        sql = """
        SELECT
            sh.veh_key,
            vs.dataset_name,
            COUNT(sh.id)          AS total_valid_sessions,
            MAX(sh.charge_segment) AS max_session_id,
            COALESCE(vp.last_session_id, 0) AS proj_last_session_id
        FROM session_history sh
        JOIN vehicle_state vs ON vs.veh_key = sh.veh_key
        LEFT JOIN vehicle_projection vp ON vp.veh_key = sh.veh_key
        WHERE sh.mileage IS NOT NULL
          AND sh.capacity_pred_smooth IS NOT NULL
        GROUP BY sh.veh_key
        HAVING total_valid_sessions >= ?
           AND (max_session_id - proj_last_session_id) >= ?
        """
        rows = self._conn().execute(sql, (min_sessions, every_n)).fetchall()
        return [dict(r) for r in rows]


    def write_kafka_lag(self, lag: int) -> None:
        with self._write_lock:
            self._conn().execute(
                "INSERT OR REPLACE INTO pipeline_lag(id, total_lag, updated_at) VALUES(1, ?, ?)",
                (lag, _utc_now()),
            )
            self._conn().commit()

    def get_kafka_lag(self) -> int:
        row = self._conn().execute(
            "SELECT total_lag FROM pipeline_lag WHERE id=1"
        ).fetchone()
        return row[0] if row else 0

    def clear_all(self) -> None:
        tables = [
            "vehicle_state", "session_history", "producer_checkpoint",
            "processed_events", "pipeline_metrics", "dead_letter",
            "vehicle_projection",
        ]
        with self._write_lock:
            for t in tables:
                self._conn().execute(f"DELETE FROM {t}")
            self._conn().commit()
        with self._dedup_lock:
            self._dedup.clear()
            self._dedup_sets.clear()



def compute_soh(capacity_ah: float, dataset_name: str) -> tuple[float, str]:
    nominal = NOMINAL_CAPACITY.get(dataset_name, 43.0)
    soh_pct = min(100.0, (capacity_ah / nominal) * 100.0)
    zone    = "Replace"
    for threshold, label in SOH_ZONES:
        if soh_pct >= threshold:
            zone = label
            break
    return round(soh_pct, 2), zone


_DEGRAD_RATE = {
    "battery_dataset1": 0.0000397,
    "battery_dataset2": 0.0000508,
    "battery_dataset3": 0.0000337,
}

def compute_rul(
    soh_pct:      float,
    mileage_km:   float,
    dataset_name: str,
    session_scores: list[float],
) -> Optional[float]:
    if soh_pct <= SOH_INTERVENTION_PCT:
        return 0.0
    if mileage_km <= 0:
        return None
    rate    = _DEGRAD_RATE.get(dataset_name, 0.0000397)
    headroom= soh_pct - SOH_INTERVENTION_PCT
    rul     = headroom / rate
    return round(min(rul, 800_000.0), 1)


def verify_state_store() -> dict:
    import tempfile, os
    results = {}

    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        tmp_path = Path(f.name)

    try:
        store = StateStore(db_path=tmp_path)
        store.init()
        results["init_ok"] = True

        store.mark_processed("abc123", "bronze")
        results["dedup_hit"]  = store.is_duplicate("abc123", "bronze")
        results["dedup_miss"] = not store.is_duplicate("xyz999", "bronze")

        cp = ProducerCheckpoint.build("battery_dataset1:42", 134, 67, "charging")
        store.save_checkpoint(cp)
        loaded = store.load_checkpoint("battery_dataset1:42")
        results["checkpoint_save_load"] = (
            loaded is not None
            and loaded.session_id == 134
            and loaded.step_index == 67
        )
        all_cps = store.load_all_checkpoints()
        results["load_all_checkpoints"] = len(all_cps) == 1

        sc = SessionCompleted(
            vehicle_id           = "battery_dataset1:42",
            session_id           = 134,
            dataset_name         = "battery_dataset1",
            car_id               = 42,
            fault_label          = 0,
            final_session_score  = 0.45,
            alarm_triggered      = False,
            n_chunks_scored      = 1,
            capacity_pred_smooth = 40.23,
            capacity_true        = None,
            mileage              = 87432.5,
            session_start_ts     = utc_now_iso(),
            session_end_ts       = utc_now_iso(),
            bronze_latency_ms    = 2.5,
            silver_latency_ms    = 8.1,
        )
        store.insert_session(sc, first_event_id="aabbccdd11223344")
        hist = store.get_session_history("battery_dataset1:42")
        results["session_insert"] = len(hist) == 1 and hist[0]["charge_segment"] == 134

        store.insert_session(sc, first_event_id="aabbccdd11223344")
        hist2 = store.get_session_history("battery_dataset1:42")
        results["session_upsert_idempotent"] = len(hist2) == 1

        upd = GoldVehicleUpdate(
            vehicle_id               = "battery_dataset1:42",
            dataset_name             = "battery_dataset1",
            car_id                   = 42,
            fault_label              = 0,
            vehicle_fault_score      = 0.45,
            alarm                    = False,
            soh_pct                  = 92.3,
            soh_zone                 = "Healthy",
            capacity_ah              = 40.23,
            capacity_source          = "lstm_pred_smooth",
            risk_score               = 0.31,
            risk_rank                = None,
            rul_km                   = 45000.0,
            mileage_km               = 87432.5,
            total_sessions           = 134,
            sessions_above_threshold = 2,
            volatility               = 0.04,
            last_session_score       = 0.45,
            last_updated             = utc_now_iso(),
            gold_latency_ms          = 14.2,
        )
        store.upsert_vehicle_state(upd)
        vs = store.get_vehicle_state("battery_dataset1:42")
        results["vehicle_state_upsert"] = vs is not None and abs(vs["soh_pct"] - 92.3) < 0.01

        summary = store.get_fleet_summary()
        results["fleet_summary"] = summary["total_vehicles"] == 1

        soh, zone = compute_soh(40.23, "battery_dataset1")
        results["soh_compute"] = zone == "Healthy" and 80 < soh < 100

        pme = PipelineMetricsEvent.build("bronze", 100, 98, 2, 0, [2.1, 3.4, 2.8])
        store.write_pipeline_metrics(pme)
        m = store.get_latest_metrics_per_stage()
        results["metrics_write"] = m["bronze"] is not None

        dle = DeadLetterEvent.build(
            topic="battery.bronze.raw", reason="bounds_violation",
            raw_payload=b'{"bad":"data"}', vehicle_id="battery_dataset1:42",
        )
        store.write_dead_letter(dle)
        dl = store.get_dead_letters()
        results["dead_letter_write"] = len(dl) == 1

        store.clear_all()
        results["clear_all"] = store.get_fleet_summary()["total_vehicles"] == 0

        store.close()

    finally:
        os.unlink(tmp_path)

    return results


if __name__ == "__main__":
    print("StateStore verification:")
    results = verify_state_store()
    all_pass = True
    for key, val in results.items():
        if isinstance(val, bool):
            status = "PASS" if val else "FAIL"
            if not val:
                all_pass = False
            print(f"  [{status}] {key}")
        else:
            print(f"  [INFO] {key}: {val}")
    print()
    print("Result:", "ALL PASS" if all_pass else "FAILURES FOUND — check above")

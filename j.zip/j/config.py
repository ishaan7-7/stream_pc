import os
from pathlib import Path

ROOT_DIR        = Path(r"C:\Battery_Health_V2")
PRESENTATION_MODE = os.getenv("PRESENTATION_MODE", "0") == "1"
DATA_DIR        = ROOT_DIR / "Data"
ARTIFACT_DIR    = ROOT_DIR / "Artifacts" / "LSTM"
TEST_OUTPUT_DIR = ROOT_DIR / "Test" / "outputs"
STATE_DIR       = ROOT_DIR / "State"
SHARED_DIR      = ROOT_DIR / "Shared"
SERVICES_DIR    = ROOT_DIR / "Services"
LOG_DIR         = ROOT_DIR / "Logs"

for _d in [STATE_DIR, LOG_DIR]:
    _d.mkdir(parents=True, exist_ok=True)

MODEL_PATH      = ARTIFACT_DIR / "battery_lstm_best.pth"
CALIBRATION_PATH= ARTIFACT_DIR / "calibration_best.json"

CAPACITY_SOURCE = DATA_DIR / "capacity" / "capacity_per_session_clean.parquet"

JAVA_HOME   = ROOT_DIR / "jdk-11.0.31+11"
KAFKA_HOME  = ROOT_DIR / "kafka"
KAFKA_BIN   = KAFKA_HOME / "bin" / "windows"
NODEJS_HOME = ROOT_DIR / "nodejs"
NPM_CACHE   = ROOT_DIR / "npm cache"

SPEED_MULTIPLIER                   = 60
BRONZE_MAX_EVENT_AGE_SEC           = 300
PRODUCER_CHECKPOINT_EVERY_N_STEPS  = 10

KAFKA_BOOTSTRAP_SERVERS  = "127.0.0.1:9092"
TOPIC_BRONZE             = "battery.bronze.raw"
TOPIC_BRONZE_DLQ         = "battery.bronze.deadletter"
TOPIC_SILVER             = "battery.silver.inference"
TOPIC_GOLD               = "battery.gold.analytics"
TOPIC_PIPELINE_METRICS   = "battery.pipeline.metrics"

KAFKA_PRODUCER_CONFIG = {
    "bootstrap_servers":  KAFKA_BOOTSTRAP_SERVERS,
    "value_serializer":   None,
    "acks":               1,
    "compression_type":   None,
    "batch_size":         65536,
    "linger_ms":          5,
    "max_block_ms":       5000,
}

KAFKA_CONSUMER_CONFIG = {
    "bootstrap_servers":  KAFKA_BOOTSTRAP_SERVERS,
    "auto_offset_reset":  "earliest",
    "enable_auto_commit": False,
    "max_poll_records":   256,
    "session_timeout_ms": 30000,
    "heartbeat_interval_ms": 10000,
}

SQLITE_PATH           = STATE_DIR / "battery_health.db"
PRESENTATION_DB_PATH  = STATE_DIR / "presentation.db"
ACTIVE_DB_PATH        = PRESENTATION_DB_PATH if PRESENTATION_MODE else SQLITE_PATH

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS vehicle_state (
    veh_key                  TEXT PRIMARY KEY,
    dataset_name             TEXT NOT NULL,
    car_id                   INTEGER NOT NULL,
    fault_label              INTEGER NOT NULL,
    split                    TEXT NOT NULL,
    status                   TEXT NOT NULL DEFAULT 'idle',
    vehicle_fault_score      REAL,
    alarm                    INTEGER DEFAULT 0,
    soh_pct                  REAL,
    soh_zone                 TEXT,
    capacity_ah              REAL,
    capacity_source          TEXT,
    risk_score               REAL,
    risk_rank                INTEGER,
    rul_km                   REAL,
    mileage_km               REAL,
    total_sessions           INTEGER DEFAULT 0,
    current_session_id       INTEGER,
    last_session_score       REAL,
    last_updated             TEXT,
    created_at               TEXT
);

CREATE TABLE IF NOT EXISTS session_history (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    veh_key              TEXT NOT NULL,
    charge_segment       INTEGER NOT NULL,
    first_event_id       TEXT,
    mileage              REAL,
    session_score        REAL,
    capacity_pred        REAL,
    capacity_pred_smooth REAL,
    capacity_true        REAL,
    fault_label          INTEGER,
    n_chunks_scored      INTEGER,
    alarm_triggered      INTEGER DEFAULT 0,
    session_start_ts     TEXT,
    session_end_ts       TEXT,
    UNIQUE(veh_key, charge_segment)
);

CREATE TABLE IF NOT EXISTS producer_checkpoint (
    vehicle_id    TEXT PRIMARY KEY,
    session_id    INTEGER NOT NULL,
    step_index    INTEGER NOT NULL,
    status        TEXT NOT NULL,
    idle_until_ts TEXT,
    saved_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS processed_events (
    event_id    TEXT PRIMARY KEY,
    stage       TEXT NOT NULL,
    processed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pipeline_metrics (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    ts                  TEXT NOT NULL,
    stage               TEXT NOT NULL,
    messages_in         INTEGER DEFAULT 0,
    messages_out        INTEGER DEFAULT 0,
    messages_rejected   INTEGER DEFAULT 0,
    messages_duplicate  INTEGER DEFAULT 0,
    avg_latency_ms      REAL,
    p99_latency_ms      REAL,
    throughput_per_sec  REAL
);

CREATE TABLE IF NOT EXISTS dead_letter (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    ts               TEXT NOT NULL,
    topic            TEXT NOT NULL,
    vehicle_id       TEXT,
    session_id       INTEGER,
    step_index       INTEGER,
    rejection_reason TEXT NOT NULL,
    raw_payload      TEXT
);

CREATE INDEX IF NOT EXISTS idx_session_veh      ON session_history(veh_key);
CREATE INDEX IF NOT EXISTS idx_session_seg      ON session_history(charge_segment);
CREATE INDEX IF NOT EXISTS idx_proc_stage       ON processed_events(stage, processed_at);
CREATE INDEX IF NOT EXISTS idx_metrics_stage    ON pipeline_metrics(stage, ts);
CREATE INDEX IF NOT EXISTS idx_dlq_vehicle      ON dead_letter(vehicle_id, ts);
CREATE INDEX IF NOT EXISTS idx_checkpoint_vid   ON producer_checkpoint(vehicle_id);

CREATE TABLE IF NOT EXISTS vehicle_projection (
    veh_key              TEXT PRIMARY KEY,
    dataset_name         TEXT NOT NULL,
    computed_at          TEXT NOT NULL,
    n_sessions_used      INTEGER NOT NULL,
    last_session_id      INTEGER NOT NULL,
    current_mileage      REAL NOT NULL,
    current_capacity     REAL NOT NULL,
    lambda_decay         REAL NOT NULL,
    c0_intercept         REAL NOT NULL,
    rul_km               REAL,
    intervention_mileage REAL,
    r_squared            REAL NOT NULL,
    confidence           TEXT NOT NULL,
    curve_points_json    TEXT NOT NULL,
    lower_bound_json     TEXT,
    upper_bound_json     TEXT,
    is_accelerating      INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_proj_veh ON vehicle_projection(veh_key);

CREATE TABLE IF NOT EXISTS pipeline_lag (
    id         INTEGER PRIMARY KEY,
    total_lag  INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);
"""


DEDUP_WINDOW_SIZE = 5000

DATASETS = ["battery_dataset1", "battery_dataset2", "battery_dataset3"]

NOMINAL_CAPACITY = {
    "battery_dataset1": 43.63,
    "battery_dataset2": 43.57,
    "battery_dataset3": 41.58,
}

SOH_ZONES = [
    (85.0, "Healthy"),
    (75.0, "Monitor"),
    (60.0, "Degrade"),
    (0.0,  "Replace"),
]

SOH_INTERVENTION_PCT = 75.0
CAP_CLIP_MIN         = 28.0
CAP_CLIP_MAX         = 46.5

RISK_WEIGHT_FAULT      = 0.5
RISK_WEIGHT_SOH        = 0.3
RISK_WEIGHT_VOLATILITY = 0.2
VOLATILITY_WINDOW      = 5

MAX_CONCURRENT_VEHICLES = 40

STEP_INTERVAL_MS  = 100
IDLE_MIN_SECONDS  = 10
IDLE_MAX_SECONDS  = 45

SESSION_SCHEDULER_TICK_MS = 50

BACKPRESSURE_HIGH_WATERMARK      = 1000
BACKPRESSURE_LOW_WATERMARK       = 200
BACKPRESSURE_CHECK_INTERVAL_SEC  = 1.0
BACKPRESSURE_SLEEP_SEC           = 0.5

PRODUCER_MAX_EVENTS_PER_SEC      = 95

CHUNK_SIZE      = 128
CHUNK_STRIDE    = 64
NUM_FEATURES    = 30
SESSION_TOP_K   = 0.20
TRAIN_RATIO     = 0.8

BASE_SENSORS    = ["v_avg", "i_charge", "soc", "v_max", "v_min", "t_max", "t_min"]
ROLLING_WINDOWS = [5, 10, 20]
SENSOR_NORM     = {
    "v_avg":    (2.5,   2.0),
    "v_max":    (2.5,   2.0),
    "v_min":    (2.5,   2.0),
    "i_charge": (0.0, 300.0),
    "soc":      (0.0, 100.0),
    "t_max":    (0.0,  80.0),
    "t_min":    (0.0,  80.0),
}

CAP_NORM_MIN   = 28.0
CAP_NORM_SCALE = 18.0
LOG1P_300K = 12.611537753776873

SENSOR_BOUNDS = {
    "v_avg":    (2.0,  5.0),
    "v_max":    (2.0,  5.0),
    "v_min":    (2.0,  5.0),
    "i_charge": (-400.0, 0.0),
    "soc":      (0.0,  100.0),
    "t_max":    (-20.0, 80.0),
    "t_min":    (-20.0, 80.0),
}

LSTM_HIDDEN1    = 64
LSTM_HIDDEN2    = 32
LSTM_META_DIM   = 2
LSTM_DROPOUT    = 0.3

API_HOST        = "0.0.0.0"
API_PORT        = 8000
API_RELOAD      = False
API_WORKERS     = 1
CORS_ORIGINS    = ["http://localhost:3000", "http://127.0.0.1:3000"]
WS_HEARTBEAT_SEC= 2

FRONTEND_PORT   = 3000

PIPELINE_METRICS_INTERVAL_SEC = 5

LOG_LEVEL   = "INFO"
LOG_FORMAT  = "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
LOG_DATE_FMT= "%Y-%m-%d %H:%M:%S"

DS_DISPLAY_NAMES = {
    "battery_dataset1": "Manufacturer A",
    "battery_dataset2": "Manufacturer B",
    "battery_dataset3": "Manufacturer C",
}

ALARM_CONFIRM_SESSIONS = 5
FAULT_SCORE_THRESHOLD_DEFAULT = 0.728

DEMO_SEED_SESSIONS = 25

CAR_ID_RANGES = {
    "battery_dataset1": (0,   216),
    "battery_dataset2": (300, 497),
    "battery_dataset3": (500, 548),
}
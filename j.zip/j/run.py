import sys
import os
import time
import signal
import subprocess
import argparse
import shutil
import sqlite3
import threading
from pathlib import Path

ROOT_DIR     = Path(__file__).parent.parent
_VENV_PYTHON = ROOT_DIR / "venv" / "Scripts" / "python.exe"
if _VENV_PYTHON.exists() and Path(sys.executable).resolve() != _VENV_PYTHON.resolve():
    print("[run.py] ERROR: Must be run with the project venv.")
    print(f"[run.py]   Use: run.bat {' '.join(sys.argv[1:])}")
    sys.exit(1)

SHARED_DIR = ROOT_DIR / "Shared"
sys.path.insert(0, str(SHARED_DIR))

from config import (
    JAVA_HOME,
    KAFKA_HOME,
    KAFKA_BIN,
    KAFKA_BOOTSTRAP_SERVERS,
    SQLITE_PATH,
    SQLITE_SCHEMA,
    STATE_DIR,
    LOG_DIR,
    TOPIC_BRONZE,
    TOPIC_BRONZE_DLQ,
    TOPIC_SILVER,
    TOPIC_GOLD,
    TOPIC_PIPELINE_METRICS,
    API_PORT,
)

SERVICES = {
    "producer":   ROOT_DIR / "Services" / "01_producer"    / "producer.py",
    "bronze":     ROOT_DIR / "Services" / "02_bronze"      / "bronze_consumer.py",
    "silver":     ROOT_DIR / "Services" / "03_silver"      / "silver_consumer.py",
    "gold":       ROOT_DIR / "Services" / "04_gold"        / "gold_consumer.py",
    "api":        ROOT_DIR / "Services" / "05_api"         / "main.py",
    "projection": ROOT_DIR / "Services" / "06_projection"  / "projection_service.py",
}

_BATCH_SCRIPT = ROOT_DIR / "Services" / "07_batch" / "batch_processor.py"

CONSUMER_GROUPS = [
    "bronze-consumer-group",
    "silver-consumer-group",
    "gold-consumer-group",
]

ALL_TOPICS = [
    TOPIC_BRONZE,
    TOPIC_BRONZE_DLQ,
    TOPIC_SILVER,
    TOPIC_GOLD,
    TOPIC_PIPELINE_METRICS,
]

_procs: dict[str, subprocess.Popen] = {}
_zk_proc:    subprocess.Popen = None
_kafka_proc: subprocess.Popen = None
_restart_counts: dict[str, int] = {}
MAX_RESTARTS = 5


def _env() -> dict:
    env = os.environ.copy()
    env["JAVA_HOME"]  = str(JAVA_HOME)
    env["KAFKA_HOME"] = str(KAFKA_HOME)
    java_bin  = str(JAVA_HOME  / "bin")
    kafka_bin = str(KAFKA_BIN)
    path = env.get("PATH", "")
    for p in (java_bin, kafka_bin):
        if p not in path:
            path = p + os.pathsep + path
    env["PATH"] = path
    return env


def _bat(name: str) -> str:
    return str(KAFKA_BIN / name)


def _print(msg: str) -> None:
    print(f"[run.py] {msg}", flush=True)


def _ps(cmd: str) -> None:
    try:
        subprocess.run(["powershell", "-Command", cmd], capture_output=True, timeout=10)
    except Exception:
        pass


def _kill_java_process(class_name_match: str) -> None:
    _ps(
        f"Get-CimInstance Win32_Process | "
        f"Where-Object {{ $_.Name -like 'java*' -and $_.CommandLine -like '*{class_name_match}*' }} | "
        f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
    )


def _kill_python_service(script_name_match: str) -> None:
    current_pid = os.getpid()
    parent_pid  = os.getppid()
    _ps(
        f"Get-CimInstance Win32_Process | "
        f"Where-Object {{ "
        f"$_.Name -like 'python*' -and "
        f"$_.CommandLine -like '*{script_name_match}*' -and "
        f"$_.ProcessId -ne {current_pid} -and "
        f"$_.ProcessId -ne {parent_pid} "
        f"}} | "
        f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
    )


def _kill_all_java() -> None:
    try:
        subprocess.run(["taskkill", "/F", "/IM", "java.exe"], capture_output=True, timeout=10)
    except Exception:
        pass


def _kill_kafka_consoles() -> None:
    for bat in ("kafka-server-start", "zookeeper-server-start"):
        _ps(
            f"Get-CimInstance Win32_Process | "
            f"Where-Object {{ $_.CommandLine -like '*{bat}*' }} | "
            f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
        )


def _kill_all_zombies() -> None:
    _print("Hunting for zombie processes...")
    current_pid = os.getpid()
    parent_pid  = os.getppid()
    folder_name = ROOT_DIR.name
    # One WMI scan kills all project Python processes — faster than 7 separate scans
    _ps(
        f"Get-CimInstance Win32_Process | "
        f"Where-Object {{ "
        f"$_.Name -like 'python*' -and "
        f"$_.CommandLine -like '*{folder_name}*' -and "
        f"$_.ProcessId -ne {current_pid} -and "
        f"$_.ProcessId -ne {parent_pid} "
        f"}} | "
        f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
    )


def _wait_kafka(timeout: float = 60.0) -> bool:
    _print("Waiting for Kafka broker to be ready...")
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            from kafka import KafkaProducer
            from kafka.errors import NoBrokersAvailable
            p = KafkaProducer(
                bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
                request_timeout_ms=3000,
                max_block_ms=3000,
            )
            p.close(timeout=1)
            _print("Kafka broker is ready.")
            return True
        except Exception:
            time.sleep(2)
    _print("ERROR: Kafka broker not available after timeout.")
    return False


def cmd_setup(args):
    _print("=== SETUP ===")

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True,   exist_ok=True)
    _print(f"Directories created: {STATE_DIR}, {LOG_DIR}")

    db_path = SQLITE_PATH
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    for stmt in SQLITE_SCHEMA.split(";"):
        stmt = stmt.strip()
        if stmt:
            conn.execute(stmt)
    conn.commit()
    conn.close()
    _print(f"SQLite initialised: {db_path}")

    _print("Checking Java...")
    if not JAVA_HOME.exists():
        _print(f"ERROR: JAVA_HOME not found at {JAVA_HOME}")
        sys.exit(1)
    _print(f"  Java: {JAVA_HOME}")

    _print("Checking Kafka...")
    if not KAFKA_HOME.exists():
        _print(f"ERROR: Kafka not found at {KAFKA_HOME}")
        sys.exit(1)
    _print(f"  Kafka: {KAFKA_HOME}")

    _print("Checking Python dependencies...")
    missing = []
    for pkg in ["kafka", "fastapi", "uvicorn", "pydantic", "torch", "numpy", "pandas", "pyarrow"]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        _print(f"Missing packages: {missing}")
        _print("Run: pip install kafka-python fastapi uvicorn[standard] pydantic torch numpy pandas pyarrow")
        sys.exit(1)
    _print("  All Python dependencies present.")

    _print("Setup complete. Run: python run.py start")


def cmd_start(args):
    _print("=== START ===")
    global _zk_proc, _kafka_proc

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True,   exist_ok=True)

    _print("Starting Zookeeper...")
    _zk_proc = subprocess.Popen(
        [_bat("zookeeper-server-start.bat"),
         str(KAFKA_HOME / "config" / "zookeeper.properties")],
        env              = _env(),
        creationflags    = subprocess.CREATE_NEW_CONSOLE,
    )
    time.sleep(5)

    _print("Starting Kafka broker...")
    _kafka_proc = subprocess.Popen(
        [_bat("kafka-server-start.bat"),
         str(KAFKA_HOME / "config" / "server.properties")],
        env           = _env(),
        creationflags = subprocess.CREATE_NEW_CONSOLE,
    )

    if not _wait_kafka(timeout=60):
        _print("Kafka failed to start. Run: python run.py fix-kafka then try again.")
        sys.exit(1)

    _print("Creating Kafka topics...")
    _create_topics()

    services_to_start = list(SERVICES.keys())
    if args.service:
        services_to_start = [s for s in args.service if s in SERVICES]

    for name in services_to_start:
        _start_service(name)
        time.sleep(1)

    _print(f"All services started. API at http://localhost:{API_PORT}")
    _print(f"API docs at http://localhost:{API_PORT}/docs")
    _print("Press Ctrl+C to stop all services.")

    try:
        while True:
            time.sleep(5)
            _check_services()
    except KeyboardInterrupt:
        _print("Keyboard interrupt — stopping...")
        cmd_stop(args)


def cmd_stop(args):
    _print("=== STOP ===")
    
    # If specific services are mentioned, only stop those and return
    if args.service:
        for name in args.service:
            if name in SERVICES:
                _stop_service(name)
            else:
                _print(f"Unknown service: {name}")
        return

    # No specific services? Perform full teardown including Kafka/Zookeeper
    if not _procs:
        _print("Notice: 'stop' called from a new terminal. Attempting global forceful cleanup...")
        _kill_all_zombies()
    else:
        for name in reversed(list(_procs.keys())):
            _stop_service(name)

    for name in SERVICES.keys():
        _kill_python_service(SERVICES[name].name)

    _print("Stopping Kafka broker...")
    if _kafka_proc and _kafka_proc.poll() is None:
        _kafka_proc.kill()
        try:
            _kafka_proc.wait(timeout=5)
        except Exception:
            pass

    _print("Stopping Zookeeper...")
    if _zk_proc and _zk_proc.poll() is None:
        _zk_proc.kill()
        try:
            _zk_proc.wait(timeout=5)
        except Exception:
            pass

    _kill_kafka_consoles()
    _kill_all_java()
    time.sleep(5)

    _print("All services stopped.")


def cmd_restart(args):
    if not args.service:
        _print("Specify service: python run.py restart <service_name>")
        _print(f"Available: {list(SERVICES.keys())}")
        return
    for name in args.service:
        if name not in SERVICES:
            _print(f"Unknown service: {name}")
            continue
        _stop_service(name)
        time.sleep(1)
        _start_service(name)


def cmd_reset(args):
    _print("=== RESET ===")
    _print("Stopping all services, including Kafka and Zookeeper...")
    
    if not _procs:
        _kill_all_zombies()
    else:
        for name in list(_procs.keys()):
            _stop_service(name)

    _kill_kafka_consoles()
    _kill_all_java()
    time.sleep(5)

    _print("Clearing SQLite state...")
    if SQLITE_PATH.exists():
        conn = sqlite3.connect(str(SQLITE_PATH))
        for table in ["vehicle_state","session_history","producer_checkpoint",
                      "processed_events","pipeline_metrics","dead_letter"]:
            conn.execute(f"DELETE FROM {table}")
        conn.commit()
        conn.close()
        _print("  SQLite cleared.")

    _print("Deleting Kafka and Zookeeper log directories...")
    server_props = KAFKA_HOME / "config" / "server.properties"
    zk_props     = KAFKA_HOME / "config" / "zookeeper.properties"
    kafka_logs = Path(r"C:\tmp\kafka-logs")
    zk_data    = Path(r"C:\tmp\zookeeper")

    for props_file, key, target in [
        (server_props, "log.dirs", "kafka_logs"),
        (zk_props,     "dataDir",  "zk_data"),
    ]:
        if props_file.exists():
            for line in props_file.read_text().splitlines():
                line = line.strip()
                if line.startswith(f"{key}="):
                    p = Path(line.split("=", 1)[1].strip())
                    if target == "kafka_logs":
                        kafka_logs = p
                    else:
                        zk_data = p

    for d in (kafka_logs, zk_data):
        if d.exists():
            for attempt in range(8):
                try:
                    shutil.rmtree(d)
                    break
                except Exception as e:
                    if attempt == 7:
                        _print(f"  Warning: Could not completely remove {d} due to locks: {e}")
                    time.sleep(2)

            d.mkdir(parents=True, exist_ok=True)
            _print(f"  Cleared: {d}")

    _print("Reset complete. All state and streams cleared. Run: python run.py start")


def cmd_fix_kafka(args):
    _print("=== FIX-KAFKA ===")
    _print("Stopping all services...")
    
    if not _procs:
        _kill_all_zombies()
    else:
        for name in list(_procs.keys()):
            _stop_service(name)

    _print("Ensuring Kafka and Zookeeper processes are dead...")
    _kill_kafka_consoles()
    _kill_all_java()
    time.sleep(5)

    _print("Deleting Kafka and Zookeeper log directories...")
    server_props = KAFKA_HOME / "config" / "server.properties"
    zk_props     = KAFKA_HOME / "config" / "zookeeper.properties"
    kafka_logs = Path(r"C:\tmp\kafka-logs")
    zk_data    = Path(r"C:\tmp\zookeeper")

    for props_file, key, target in [
        (server_props, "log.dirs", "kafka_logs"),
        (zk_props,     "dataDir",  "zk_data"),
    ]:
        if props_file.exists():
            for line in props_file.read_text().splitlines():
                line = line.strip()
                if line.startswith(f"{key}="):
                    p = Path(line.split("=", 1)[1].strip())
                    if target == "kafka_logs":
                        kafka_logs = p
                    else:
                        zk_data = p

    for d in (kafka_logs, zk_data):
        if d.exists():
            for attempt in range(8):
                try:
                    shutil.rmtree(d)
                    break
                except Exception as e:
                    if attempt == 7:
                        _print(f"  Warning: Could not completely remove {d} due to locks: {e}")
                    time.sleep(2)

            d.mkdir(parents=True, exist_ok=True)
            _print(f"  Cleared: {d}")

    _print("Kafka logs cleared. Run: python run.py start")


def cmd_status(args):
    _print("=== STATUS ===")

    kafka_ok = False
    try:
        from kafka import KafkaProducer
        p = KafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            request_timeout_ms=2000,
            max_block_ms=2000,
        )
        p.close(timeout=1)
        kafka_ok = True
    except Exception:
        pass

    print(f"  Kafka broker   : {'RUNNING' if kafka_ok else 'OFFLINE'}")

    for name, proc in _procs.items():
        alive = proc.poll() is None
        print(f"  {name:<12}: {'RUNNING' if alive else 'STOPPED'} (pid={proc.pid})")

    if SQLITE_PATH.exists():
        conn = sqlite3.connect(str(SQLITE_PATH))
        try:
            total  = conn.execute("SELECT COUNT(*) FROM vehicle_state").fetchone()[0]
            alarms = conn.execute("SELECT COUNT(*) FROM vehicle_state WHERE alarm=1").fetchone()[0]
            sessions = conn.execute("SELECT COUNT(*) FROM session_history").fetchone()[0]
            dl     = conn.execute("SELECT COUNT(*) FROM dead_letter").fetchone()[0]
            print(f"  SQLite         : vehicles={total} alarms={alarms} sessions={sessions} dead_letters={dl}")
        except Exception:
            print("  SQLite         : exists but schema not initialised")
        finally:
            conn.close()
    else:
        print("  SQLite         : not found")


def _start_service(name: str) -> None:
    if name in _procs and _procs[name].poll() is None:
        _print(f"  {name} already running (pid={_procs[name].pid})")
        return
    script = SERVICES[name]
    if not script.exists():
        _print(f"  ERROR: {script} not found — skipping {name}")
        return
    proc = subprocess.Popen(
        [sys.executable, str(script)],
        env           = _env(),
        creationflags = subprocess.CREATE_NEW_CONSOLE,
    )
    _procs[name] = proc
    _print(f"  Started {name} (pid={proc.pid})")


def _stop_service(name: str) -> None:
    proc = _procs.get(name)
    if proc is None:
        return
    if proc.poll() is None:
        proc.kill()
        try:
            proc.wait(timeout=5)
        except Exception:
            pass
    _procs.pop(name, None)
    _print(f"  Stopped {name}")


def _check_services() -> None:
    for name, proc in list(_procs.items()):
        if proc.poll() is not None:
            count = _restart_counts.get(name, 0)
            if count >= MAX_RESTARTS:
                _print(f"CRITICAL: {name} failed {count} times. Disabling auto-restart.")
                _print(f"          -> Please check the logs at {LOG_DIR}\\{name}.log for the crash reason.")
                _procs.pop(name, None)
                continue
                
            _restart_counts[name] = count + 1
            _print(f"WARNING: {name} exited (code={proc.returncode}) — restarting (attempt {count+1}/{MAX_RESTARTS})...")
            _start_service(name)


def _create_topics() -> None:
    from kafka.admin import KafkaAdminClient, NewTopic
    from kafka.errors import TopicAlreadyExistsError
    try:
        admin    = KafkaAdminClient(bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS, request_timeout_ms=10000)
        existing = set(admin.list_topics())
        to_make  = [
            NewTopic(name=t, num_partitions=1, replication_factor=1)
            for t in ALL_TOPICS if t not in existing
        ]
        if to_make:
            admin.create_topics(to_make, validate_only=False)
            _print(f"  Created topics: {[t.name for t in to_make]}")
        else:
            _print("  All topics already exist.")
        admin.close()
    except TopicAlreadyExistsError:
        pass
    except Exception as e:
        _print(f"  Topic creation error: {e}")


def _reset_consumer_offsets() -> None:
    env = _env()
    for gid in CONSUMER_GROUPS:
        cmd = [
            _bat("kafka-consumer-groups.bat"),
            "--bootstrap-server", KAFKA_BOOTSTRAP_SERVERS,
            "--group", gid,
            "--reset-offsets",
            "--to-earliest",
            "--all-topics",
            "--execute",
        ]
        result = subprocess.run(cmd, env=env, capture_output=True)
        if result.returncode == 0:
            _print(f"  Reset offsets for group: {gid}")
        else:
            _print(f"  Failed to reset {gid}: {result.stderr.decode()[:200]}")


def cmd_batch(args):
    _print("=== BATCH PROCESSOR ===")
    _print("Building presentation.db — LSTM inference on all sessions for all vehicles.")
    _print("This runs without Kafka. Estimated time: 10-20 minutes.")
    _print(f"Output: {ROOT_DIR / 'State' / 'presentation.db'}")
    _print("")

    if not _BATCH_SCRIPT.exists():
        _print(f"ERROR: {_BATCH_SCRIPT} not found")
        return

    proc = subprocess.run(
        [sys.executable, str(_BATCH_SCRIPT)],
        env = _env(),
    )
    if proc.returncode == 0:
        _print("Batch complete. Run: run.bat presentation")
    else:
        _print(f"Batch failed with exit code {proc.returncode}. Check Logs/batch.log")


def cmd_presentation(args):
    _print("=== PRESENTATION MODE ===")
    _print("Starting API only — no Kafka, no stream services.")
    _print("Serving completed dataset from existing battery_health.db")

    api_script = SERVICES["api"]
    if not api_script.exists():
        _print(f"ERROR: {api_script} not found")
        return

    env                        = _env()
    env["PRESENTATION_MODE"]   = "1"

    proc = subprocess.Popen(
        [sys.executable, str(api_script)],
        env           = env,
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP,
    )
    _print(f"API started (pid={proc.pid})  — http://localhost:8000")
    _print("Press Ctrl+C to stop.")

    try:
        proc.wait()
    except KeyboardInterrupt:
        _print("Stopping presentation mode...")
        proc.kill()
        try:
            proc.wait(timeout=5)
        except Exception:
            pass
    _print("Presentation mode stopped.")


def main():
    parser = argparse.ArgumentParser(
        prog        = "run.py",
        description = "Battery Health Demo Controller",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("setup",    help="Check dependencies, init SQLite, verify Java/Kafka paths")
    sub.add_parser("fix-kafka",help="Delete corrupted Kafka/ZK log dirs (run when Kafka won't start)")
    sub.add_parser("status",   help="Show status of all services and SQLite")

    p_start = sub.add_parser("start", help="Start Kafka + all services")
    p_start.add_argument("service", nargs="*", help="Start specific services only (optional)")

    p_stop = sub.add_parser("stop", help="Stop all services and Kafka")
    p_stop.add_argument("service", nargs="*")

    p_restart = sub.add_parser("restart", help="Restart specific service(s)")
    p_restart.add_argument("service", nargs="+", choices=list(SERVICES.keys()))

    sub.add_parser("reset", help="Clear SQLite + Kafka offsets, restart pipeline services fresh")
    
    sub.add_parser("kill-zombies",   help="Aggressively kill any background Python/Java process related to this project")
    sub.add_parser("batch",          help="Build presentation.db — run LSTM on all sessions offline (10-20 min, no Kafka needed)")
    sub.add_parser("presentation",   help="Start API only in presentation mode — serves presentation.db with streaming fields zeroed")

    args = parser.parse_args()

    commands = {
        "setup":     cmd_setup,
        "start":     cmd_start,
        "stop":      cmd_stop,
        "restart":   cmd_restart,
        "reset":     cmd_reset,
        "fix-kafka": cmd_fix_kafka,
        "status":    cmd_status,
        "kill-zombies":  lambda a: (_kill_all_zombies(), _kill_all_java(), _print("Zombies eliminated.")),
        "batch":         cmd_batch,
        "presentation":  cmd_presentation,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
import sys
import os
import time
import signal
import subprocess
import argparse
import shutil
import sqlite3
import threading
import socket
import re
from pathlib import Path

# --- 1. Environment & Path Initialization ---
ROOT_DIR     = Path(__file__).parent.parent
_VENV_PYTHON = ROOT_DIR / "venv" / "Scripts" / "python.exe"

# Enforce Virtual Environment execution
if _VENV_PYTHON.exists() and Path(sys.executable).resolve() != _VENV_PYTHON.resolve():
    print("[run.py] ERROR: Must be run with the project venv.")
    print(f"[run.py]   Use: run.bat {' '.join(sys.argv[1:])}")
    sys.exit(1)

SHARED_DIR = ROOT_DIR / "Shared"
sys.path.insert(0, str(SHARED_DIR))

from config import (
    JAVA_HOME,
    KAFKA_HOME,
    KAFKA_BIN,
    NODEJS_HOME,
    KAFKA_BOOTSTRAP_SERVERS,
    SQLITE_PATH,
    PRESENTATION_DB_PATH,
    SQLITE_SCHEMA,
    STATE_DIR,
    LOG_DIR,
    TOPIC_BRONZE,
    TOPIC_BRONZE_DLQ,
    TOPIC_SILVER,
    TOPIC_GOLD,
    TOPIC_PIPELINE_METRICS,
    API_PORT,
    DEMO_SEED_SESSIONS,
)

# --- 2. Service Definitions ---
SERVICES = {
    "producer":   ROOT_DIR / "Services" / "01_producer"    / "producer.py",
    "bronze":     ROOT_DIR / "Services" / "02_bronze"      / "bronze_consumer.py",
    "silver":     ROOT_DIR / "Services" / "03_silver"      / "silver_consumer.py",
    "gold":       ROOT_DIR / "Services" / "04_gold"        / "gold_consumer.py",
    "api":        ROOT_DIR / "Services" / "05_api"         / "main.py",
    "projection": ROOT_DIR / "Services" / "06_projection"  / "projection_service.py",
}

_BATCH_SCRIPT = ROOT_DIR / "Services" / "07_batch" / "batch_processor.py"
_SEED_SCRIPT  = ROOT_DIR / "Services" / "07_batch" / "seed_processor.py"
_STOP_FILE    = STATE_DIR / ".stop_pipeline"

CONSUMER_GROUPS = [
    "bronze-consumer-group",
    "silver-consumer-group",
    "gold-consumer-group",
]

ALL_TOPICS = [
    TOPIC_BRONZE,
    TOPIC_BRONZE_DLQ,
    TOPIC_SILVER,
    TOPIC_GOLD,
    TOPIC_PIPELINE_METRICS,
]

# --- 3. Global State ---
_procs: dict[str, subprocess.Popen] = {}
_zk_proc:    subprocess.Popen = None
_kafka_proc: subprocess.Popen = None
_restart_counts: dict[str, int] = {}
MAX_RESTARTS = 5

# --- 4. Core Utilities ---
def _env() -> dict:
    env = os.environ.copy()
    env["JAVA_HOME"]  = str(JAVA_HOME)
    env["KAFKA_HOME"] = str(KAFKA_HOME)
    java_bin   = str(JAVA_HOME  / "bin")
    kafka_bin  = str(KAFKA_BIN)
    nodejs_bin = str(NODEJS_HOME)
    path = env.get("PATH", "")
    for p in (java_bin, kafka_bin, nodejs_bin):
        if p not in path:
            path = p + os.pathsep + path
    env["PATH"] = path
    return env

def _bat(name: str) -> str:
    return str(KAFKA_BIN / name)

def _print(msg: str) -> None:
    print(f"[run.py] {msg}", flush=True)

def _ps(cmd: str) -> None:
    try:
        subprocess.run(["powershell", "-Command", cmd], capture_output=True, timeout=10)
    except Exception:
        pass

def _is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0

def _print_db_stats(name: str, db_path: Path):
    if db_path.exists():
        conn = sqlite3.connect(str(db_path))
        try:
            total  = conn.execute("SELECT COUNT(*) FROM vehicle_state").fetchone()[0]
            alarms = conn.execute("SELECT COUNT(*) FROM vehicle_state WHERE alarm=1").fetchone()[0]
            sessions = conn.execute("SELECT COUNT(*) FROM session_history").fetchone()[0]
            dl     = conn.execute("SELECT COUNT(*) FROM dead_letter").fetchone()[0]
            print(f"  {name:<14} : vehicles={total} alarms={alarms} sessions={sessions} dead_letters={dl}")
        except Exception:
            print(f"  {name:<14} : exists but schema not initialised")
        finally:
            conn.close()
    else:
        print(f"  {name:<14} : not found")

# --- 5. OS-Level Process Management ---
def _kill_python_service(script_name_match: str) -> None:
    current_pid = os.getpid()
    parent_pid  = os.getppid()
    safe_path   = re.escape(str(ROOT_DIR)).replace('\\', '\\\\')
    
    _ps(
        f"Get-CimInstance Win32_Process | "
        f"Where-Object {{ "
        f"$_.Name -like 'python*' -and "
        f"$_.CommandLine -match '{safe_path}' -and "
        f"$_.CommandLine -like '*{script_name_match}*' -and "
        f"$_.ProcessId -ne {current_pid} -and "
        f"$_.ProcessId -ne {parent_pid} "
        f"}} | "
        f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
    )

def _kill_all_zombies() -> None:
    _print("Hunting for orphaned processes natively tied to this directory...")
    current_pid = os.getpid()
    parent_pid  = os.getppid()
    safe_path   = re.escape(str(ROOT_DIR)).replace('\\', '\\\\')
    
    _ps(
        f"Get-CimInstance Win32_Process | "
        f"Where-Object {{ "
        f"$_.Name -like 'python*' -and "
        f"$_.CommandLine -match '{safe_path}' -and "
        f"$_.ProcessId -ne {current_pid} -and "
        f"$_.ProcessId -ne {parent_pid} "
        f"}} | "
        f"ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }}"
    )

def _kill_all_java() -> None:
    try:
        subprocess.run(["taskkill", "/F", "/IM", "java.exe"], capture_output=True, timeout=10)
    except Exception:
        pass

def _is_service_running_os(script_name: str) -> bool:
    safe_path = re.escape(str(ROOT_DIR)).replace('\\', '\\\\')
    cmd = (
        f"(Get-CimInstance Win32_Process | "
        f"Where-Object {{ $_.Name -like 'python*' -and $_.CommandLine -match '{safe_path}' -and $_.CommandLine -like '*{script_name}*' }}).Count"
    )
    res = subprocess.run(["powershell", "-Command", cmd], capture_output=True, text=True)
    try:
        return int(res.stdout.strip()) > 0
    except ValueError:
        return False

# --- 6. Master-Thread Graceful Shutdown ---
def _graceful_shutdown_from_main_thread():
    """Executed by the main controller terminal. Signals processes gracefully via PID."""
    _print("=== SHUTDOWN SEQUENCE INITIATED ===")
    
    # 1. Stop Python services first
    for name in reversed(list(_procs.keys())):
        _stop_service(name)
        
    # 2. Gracefully signal Kafka via Process Group OS Signal
    if _kafka_proc and _kafka_proc.poll() is None:
        _print("Transmitting graceful termination signal to Kafka (flushing RAM)...")
        try:
            # Sends a safe interrupt to the process group, bypassing Window Title bugs
            os.kill(_kafka_proc.pid, signal.CTRL_BREAK_EVENT)
            _kafka_proc.wait(timeout=15)
            _print("Kafka shut down gracefully.")
        except Exception as e:
            _print(f"Kafka graceful shutdown timed out or failed: {e}")
            _kafka_proc.kill()
            
    # 3. Gracefully signal ZooKeeper
    if _zk_proc and _zk_proc.poll() is None:
        _print("Transmitting graceful termination signal to ZooKeeper...")
        try:
            os.kill(_zk_proc.pid, signal.CTRL_BREAK_EVENT)
            _zk_proc.wait(timeout=10)
            _print("ZooKeeper shut down gracefully.")
        except Exception as e:
            _print(f"ZooKeeper graceful shutdown timed out or failed: {e}")
            _zk_proc.kill()

    _print("Main controller shutdown complete.")

# --- 7. Kafka Orchestration ---
def _wait_kafka(timeout: float = 60.0) -> bool:
    _print("Waiting for Kafka broker to be ready...")
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            from kafka import KafkaProducer
            p = KafkaProducer(
                bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
                request_timeout_ms=3000,
                max_block_ms=3000,
            )
            p.close(timeout=1)
            _print("Kafka broker socket is active.")
            return True
        except Exception:
            time.sleep(2)
    _print("ERROR: Kafka broker not available after timeout.")
    return False

def _create_topics() -> None:
    from kafka.admin import KafkaAdminClient, NewTopic
    from kafka.errors import TopicAlreadyExistsError
    
    _print("Creating Kafka topics...")
    for attempt in range(5):
        try:
            admin = KafkaAdminClient(bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS, request_timeout_ms=5000)
            existing = set(admin.list_topics())
            to_make  = [
                NewTopic(name=t, num_partitions=1, replication_factor=1)
                for t in ALL_TOPICS if t not in existing
            ]
            if to_make:
                admin.create_topics(to_make, validate_only=False)
                _print(f"  Created topics: {[t.name for t in to_make]}")
            else:
                _print("  All topics already exist.")
            admin.close()
            return
        except TopicAlreadyExistsError:
            return
        except Exception as e:
            _print(f"  Broker not ready to create topics (Attempt {attempt+1}/5): {e}")
            time.sleep(3)
    _print("  ERROR: Failed to create topics after 5 attempts.")

# --- 8. Service Orchestration ---
def _start_service(name: str) -> None:
    if name in _procs and _procs[name].poll() is None:
        _print(f"  {name} already running (pid={_procs[name].pid})")
        return
    script = SERVICES[name]
    if not script.exists():
        _print(f"  ERROR: {script} not found — skipping {name}")
        return
    proc = subprocess.Popen(
        [sys.executable, str(script)],
        env           = _env(),
        cwd           = str(ROOT_DIR),
        creationflags = subprocess.CREATE_NEW_CONSOLE,
    )
    _procs[name] = proc
    _restart_counts[name] = 0
    _print(f"  Started {name} (pid={proc.pid})")

def _stop_service(name: str) -> None:
    proc = _procs.get(name)
    if proc is None:
        return
    if proc.poll() is None:
        proc.kill()
        try:
            proc.wait(timeout=5)
        except Exception:
            pass
    _procs.pop(name, None)
    _print(f"  Stopped {name}")

def _check_services() -> None:
    for name, proc in list(_procs.items()):
        if proc.poll() is not None:
            count = _restart_counts.get(name, 0)
            if count >= MAX_RESTARTS:
                _print(f"CRITICAL: {name} failed {count} times. Disabling auto-restart.")
                _print(f"          -> Check the logs at {LOG_DIR}\\{name}.log for the crash reason.")
                _procs.pop(name, None)
                continue
                
            _restart_counts[name] = count + 1
            _print(f"WARNING: {name} exited (code={proc.returncode}) — restarting (attempt {count+1}/{MAX_RESTARTS})...")
            _start_service(name)

# --- 9. Command Handlers ---
def cmd_setup(args):
    _print("=== SETUP ===")
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True,   exist_ok=True)
    _print(f"Directories created: {STATE_DIR}, {LOG_DIR}")

    db_path = SQLITE_PATH
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    for stmt in SQLITE_SCHEMA.split(";"):
        stmt = stmt.strip()
        if stmt:
            conn.execute(stmt)
    conn.commit()
    conn.close()
    _print(f"SQLite initialised: {db_path}")

    if not JAVA_HOME.exists():
        _print(f"ERROR: JAVA_HOME not found at {JAVA_HOME}")
        sys.exit(1)
    
    if not KAFKA_HOME.exists():
        _print(f"ERROR: Kafka not found at {KAFKA_HOME}")
        sys.exit(1)

    _print("Setup complete. Run: python run.py start")

def cmd_start(args):
    _print("=== START ===")
    global _zk_proc, _kafka_proc

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True,   exist_ok=True)

    services_to_start = list(SERVICES.keys())
    if args.service:
        invalid_services = [s for s in args.service if s not in SERVICES]
        if invalid_services:
            _print(f"ERROR: Unknown service(s) requested: {invalid_services}")
            _print(f"Available services to start: {list(SERVICES.keys())}")
            sys.exit(1)
        services_to_start = args.service

    if "api" in services_to_start and _is_port_in_use(API_PORT):
        _print(f"CRITICAL ERROR: Port {API_PORT} is already in use!")
        _print("Run 'run.bat kill-zombies' or free the port before starting.")
        sys.exit(1)

    if _STOP_FILE.exists():
        _STOP_FILE.unlink()

    # Launching with Process Group flags to allow direct OS signals (CTRL_BREAK)
    _print("Starting Zookeeper...")
    _zk_proc = subprocess.Popen(
        [_bat("zookeeper-server-start.bat"), str(KAFKA_HOME / "config" / "zookeeper.properties")],
        env=_env(), cwd=str(LOG_DIR),
        creationflags=subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NEW_PROCESS_GROUP
    )
    time.sleep(5)

    _print("Starting Kafka broker...")
    _kafka_proc = subprocess.Popen(
        [_bat("kafka-server-start.bat"), str(KAFKA_HOME / "config" / "server.properties")],
        env=_env(), cwd=str(LOG_DIR),
        creationflags=subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NEW_PROCESS_GROUP
    )

    if not _wait_kafka(timeout=60):
        _print("Kafka failed to start. Run: python run.py fix-kafka then try again.")
        sys.exit(1)

    _create_topics()

    for name in services_to_start:
        _start_service(name)
        time.sleep(1)

    _print(f"All services started. API at http://localhost:{API_PORT}")
    _print("Press Ctrl+C to stop all services.")

    try:
        while True:
            time.sleep(2)
            # Master terminal watches for signals from secondary terminals
            if _STOP_FILE.exists():
                _print("Remote stop signal received.")
                _STOP_FILE.unlink()
                break
            _check_services()
    except KeyboardInterrupt:
        _print("Keyboard interrupt — stopping...")

    _graceful_shutdown_from_main_thread()

def cmd_stop(args):
    # Target specific services
    if args.service:
        for name in args.service:
            if name in SERVICES:
                _print(f"Killing service: {name}")
                if name in _procs:
                    _stop_service(name)
                else:
                    _kill_python_service(SERVICES[name].name)
            else:
                _print(f"Unknown service: {name}")
        return

    _print("=== STOP ===")
    
    # Check if the main controller (run.bat start) is actively running
    safe_path = re.escape(str(ROOT_DIR)).replace('\\', '\\\\')
    check_cmd = (
        f"(Get-CimInstance Win32_Process | "
        f"Where-Object {{ $_.Name -like 'python*' -and $_.CommandLine -match '{safe_path}' -and $_.CommandLine -like '*run.py*start*' }}).Count"
    )
    res = subprocess.run(["powershell", "-Command", check_cmd], capture_output=True, text=True)
    
    is_main_running = False
    try:
        is_main_running = int(res.stdout.strip()) > 0
    except ValueError:
        pass

    if is_main_running:
        _print("Main controller detected. Transmitting remote graceful shutdown signal...")
        _STOP_FILE.touch()
        
        # Wait up to 20 seconds for the main controller to finish its graceful teardown
        for _ in range(20):
            res = subprocess.run(["powershell", "-Command", check_cmd], capture_output=True, text=True)
            try:
                if int(res.stdout.strip()) == 0:
                    _print("Main controller successfully executed graceful shutdown.")
                    break
            except ValueError:
                pass
            time.sleep(1)
            
    # Always execute a final sweeping cleanup just in case the main terminal crashed or was closed manually
    _print("Executing final sweeping cleanup to catch orphans...")
    _kill_all_zombies()
    _kill_all_java()
    time.sleep(2)
    
    if _STOP_FILE.exists():
        _STOP_FILE.unlink()
        
    _print("All services stopped.")

def cmd_restart(args):
    if not args.service:
        _print("Specify service: python run.py restart <service_name>")
        _print(f"Available: {list(SERVICES.keys())}")
        return
    for name in args.service:
        if name not in SERVICES:
            _print(f"Unknown service: {name}")
            continue
        _print(f"Terminating {name}...")
        
        if name in _procs:
            _stop_service(name)
            time.sleep(1)
            _start_service(name)
        else:
            _kill_python_service(SERVICES[name].name)
            _print(f"  {name} stopped. The main controller loop will auto-restart it within 5 seconds.")

def cmd_reset(args):
    _print("=== RESET ===")
    # Utilize the highly robust cmd_stop sequence to gracefully close things before wiping files
    args.service = []
    cmd_stop(args)

    _print("Clearing SQLite state...")
    if SQLITE_PATH.exists():
        conn = sqlite3.connect(str(SQLITE_PATH))
        for table in ["vehicle_state","session_history","producer_checkpoint",
                      "processed_events","pipeline_metrics","dead_letter"]:
            conn.execute(f"DELETE FROM {table}")
        conn.commit()
        conn.close()
        _print("  SQLite cleared.")

    _print("Deleting Kafka and Zookeeper log directories...")
    server_props = KAFKA_HOME / "config" / "server.properties"
    zk_props     = KAFKA_HOME / "config" / "zookeeper.properties"
    
    dirs_to_delete = [Path(r"C:\tmp\zookeeper")]
    
    if server_props.exists():
        for line in server_props.read_text().splitlines():
            line = line.strip()
            if "log.dirs" in line and not line.startswith("#"):
                paths_str = line.split("=", 1)[1].strip()
                for path_str in paths_str.split(","):
                    dirs_to_delete.append(Path(path_str.strip()))
                    
    if zk_props.exists():
        for line in zk_props.read_text().splitlines():
            line = line.strip()
            if "dataDir" in line and not line.startswith("#"):
                dirs_to_delete.append(Path(line.split("=", 1)[1].strip()))

    for d in set(dirs_to_delete):
        if d.exists():
            for attempt in range(8):
                try:
                    shutil.rmtree(d)
                    break
                except Exception as e:
                    if attempt == 7:
                        _print(f"  Warning: Could not completely remove {d} due to locks: {e}")
                    time.sleep(2)
            d.mkdir(parents=True, exist_ok=True)
            _print(f"  Cleared: {d}")

    _print("Reset complete. All state and streams cleared. Run: python run.py start")

def cmd_fix_kafka(args):
    _print("=== FIX-KAFKA ===")
    args.service = []
    cmd_stop(args)

    _print("Deleting Kafka and Zookeeper log directories...")
    server_props = KAFKA_HOME / "config" / "server.properties"
    zk_props     = KAFKA_HOME / "config" / "zookeeper.properties"
    
    dirs_to_delete = [Path(r"C:\tmp\zookeeper")]
    
    if server_props.exists():
        for line in server_props.read_text().splitlines():
            line = line.strip()
            if "log.dirs" in line and not line.startswith("#"):
                paths_str = line.split("=", 1)[1].strip()
                for path_str in paths_str.split(","):
                    dirs_to_delete.append(Path(path_str.strip()))
                    
    if zk_props.exists():
        for line in zk_props.read_text().splitlines():
            line = line.strip()
            if "dataDir" in line and not line.startswith("#"):
                dirs_to_delete.append(Path(line.split("=", 1)[1].strip()))

    for d in set(dirs_to_delete):
        if d.exists():
            for attempt in range(8):
                try:
                    shutil.rmtree(d)
                    break
                except Exception as e:
                    if attempt == 7:
                        _print(f"  Warning: Could not completely remove {d} due to locks: {e}")
                    time.sleep(2)
            d.mkdir(parents=True, exist_ok=True)
            _print(f"  Cleared: {d}")

    _print("Kafka logs cleared. Run: python run.py start")

def cmd_status(args):
    _print("=== STATUS ===")

    kafka_ok = False
    try:
        from kafka import KafkaProducer
        p = KafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            request_timeout_ms=2000,
            max_block_ms=2000,
        )
        p.close(timeout=1)
        kafka_ok = True
    except Exception:
        pass

    print(f"  Kafka broker   : {'RUNNING' if kafka_ok else 'OFFLINE'}")

    for name, script in SERVICES.items():
        if name in _procs and _procs[name].poll() is None:
            print(f"  {name:<12}: RUNNING (Managed by this terminal, pid={_procs[name].pid})")
        elif _is_service_running_os(script.name):
            print(f"  {name:<12}: RUNNING (Running in background terminal)")
        else:
            print(f"  {name:<12}: STOPPED")

    _print_db_stats("Live SQLite", SQLITE_PATH)
    _print_db_stats("Present SQLite", PRESENTATION_DB_PATH)

def cmd_batch(args):
    _print("=== BATCH PROCESSOR ===")
    if not _BATCH_SCRIPT.exists():
        _print(f"ERROR: {_BATCH_SCRIPT} not found")
        return

    proc = subprocess.run([sys.executable, str(_BATCH_SCRIPT)], env=_env(), cwd=str(ROOT_DIR))
    if proc.returncode == 0:
        _print("Batch complete. Run: run.bat presentation")
    else:
        _print(f"Batch failed with exit code {proc.returncode}. Check Logs/batch.log")

def cmd_presentation(args):
    _print("=== PRESENTATION MODE ===")
    api_script = SERVICES["api"]
    if not api_script.exists():
        _print(f"ERROR: {api_script} not found")
        return

    if _is_port_in_use(API_PORT):
        _print(f"CRITICAL ERROR: Port {API_PORT} is already in use!")
        _print("Run 'run.bat kill-zombies' or free the port before starting.")
        return

    _print("Starting API only — no Kafka, no stream services.")
    _print(f"Serving offline dataset from: {PRESENTATION_DB_PATH}")

    env = _env()
    env["PRESENTATION_MODE"] = "1"

    proc = subprocess.Popen(
        [sys.executable, str(api_script)],
        env           = env,
        cwd           = str(ROOT_DIR),
        creationflags = subprocess.CREATE_NEW_CONSOLE,
    )
    
    _procs["api"] = proc
    _print(f"API started (pid={proc.pid})  — http://localhost:{API_PORT}")
    _print("Close the new API console window, press Ctrl+C here, or run 'run.bat stop' to exit.")

    try:
        while proc.poll() is None:
            time.sleep(1)
    except KeyboardInterrupt:
        _print("Keyboard interrupt detected. Stopping presentation mode...")
        if proc.poll() is None:
            proc.kill()
            try:
                proc.wait(timeout=5)
            except Exception:
                pass
        
        _kill_python_service(api_script.name)
        
    _print("Presentation mode stopped.")


def _is_demo_seeded() -> bool:
    if not SQLITE_PATH.exists():
        return False
    try:
        conn = sqlite3.connect(str(SQLITE_PATH))
        session_count    = conn.execute("SELECT COUNT(*) FROM session_history").fetchone()[0]
        checkpoint_count = conn.execute("SELECT COUNT(*) FROM producer_checkpoint").fetchone()[0]
        conn.close()
        return session_count > 0 and checkpoint_count > 0
    except Exception:
        return False


def cmd_demo(args):
    _print("=== DEMO MODE ===")
    _print(f"  Warm-start: first {DEMO_SEED_SESSIONS} sessions pre-seeded, stream continues from there.")
    global _zk_proc, _kafka_proc

    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True,   exist_ok=True)

    if _is_port_in_use(API_PORT):
        _print(f"CRITICAL ERROR: Port {API_PORT} is already in use!")
        _print("Run 'run.bat kill-zombies' or free the port before starting.")
        sys.exit(1)

    if _STOP_FILE.exists():
        _STOP_FILE.unlink()

    _print("Starting ZooKeeper...")
    _zk_proc = subprocess.Popen(
        [_bat("zookeeper-server-start.bat"), str(KAFKA_HOME / "config" / "zookeeper.properties")],
        env=_env(), cwd=str(LOG_DIR),
        creationflags=subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NEW_PROCESS_GROUP,
    )
    time.sleep(5)

    _print("Starting Kafka broker...")
    _kafka_proc = subprocess.Popen(
        [_bat("kafka-server-start.bat"), str(KAFKA_HOME / "config" / "server.properties")],
        env=_env(), cwd=str(LOG_DIR),
        creationflags=subprocess.CREATE_NEW_CONSOLE | subprocess.CREATE_NEW_PROCESS_GROUP,
    )

    if not _wait_kafka(timeout=60):
        _print("Kafka failed to start. Run: run.bat fix-kafka")
        sys.exit(1)

    _create_topics()

    if _is_demo_seeded():
        _print("Demo DB already seeded — skipping seed phase, resuming stream.")
    else:
        if not _SEED_SCRIPT.exists():
            _print(f"ERROR: Seed script not found at {_SEED_SCRIPT}")
            sys.exit(1)
        _print(f"Seeding database — first {DEMO_SEED_SESSIONS} sessions per vehicle (LSTM inference)...")
        _print("  This takes 3–8 minutes. Check Logs/seed.log for progress.")
        result = subprocess.run(
            [sys.executable, str(_SEED_SCRIPT)],
            env=_env(),
            cwd=str(ROOT_DIR),
        )
        if result.returncode != 0:
            _print(f"Seed processor failed (exit code {result.returncode}). Check Logs/seed.log")
            sys.exit(1)
        _print("Seeding complete.")

    _print("Starting streaming services...")
    for name in SERVICES:
        _start_service(name)
        time.sleep(1)

    _print(f"Demo mode live — API at http://localhost:{API_PORT}")
    _print(f"  {DEMO_SEED_SESSIONS} sessions/vehicle pre-loaded, producer streaming from next session onwards.")
    _print("Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(2)
            if _STOP_FILE.exists():
                _print("Remote stop signal received.")
                _STOP_FILE.unlink()
                break
            _check_services()
    except KeyboardInterrupt:
        _print("Keyboard interrupt — stopping...")

    _graceful_shutdown_from_main_thread()


# --- 10. Entry Point ---
def main():
    parser = argparse.ArgumentParser(prog="run.py", description="Battery Health Demo Controller")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("setup",    help="Check dependencies, init SQLite, verify Java/Kafka paths")
    sub.add_parser("fix-kafka",help="Delete corrupted Kafka/ZK log dirs (run when Kafka won't start)")
    sub.add_parser("status",   help="Show status of all services and SQLite")

    p_start = sub.add_parser("start", help="Start Kafka + all services")
    p_start.add_argument("service", nargs="*", help="Start specific services only (optional)")

    p_stop = sub.add_parser("stop", help="Stop all services and Kafka")
    p_stop.add_argument("service", nargs="*")

    p_restart = sub.add_parser("restart", help="Restart specific service(s)")
    p_restart.add_argument("service", nargs="+", choices=list(SERVICES.keys()))

    sub.add_parser("reset", help="Clear SQLite + Kafka offsets, restart pipeline services fresh")
    sub.add_parser("kill-zombies", help="Aggressively kill any background Python/Java process related to this project")
    sub.add_parser("batch",        help="Build presentation.db — run LSTM on all sessions offline")
    sub.add_parser("presentation", help="Start API only in presentation mode (static, no Kafka)")
    sub.add_parser("demo",         help=f"Seed first {DEMO_SEED_SESSIONS} sessions/vehicle then stream live")

    args = parser.parse_args()

    commands = {
        "setup":         cmd_setup,
        "start":         cmd_start,
        "stop":          cmd_stop,
        "restart":       cmd_restart,
        "reset":         cmd_reset,
        "fix-kafka":     cmd_fix_kafka,
        "status":        cmd_status,
        "kill-zombies":  lambda a: (_kill_all_zombies(), _kill_all_java(), _print("Zombies eliminated.")),
        "batch":         cmd_batch,
        "presentation":  cmd_presentation,
        "demo":          cmd_demo,
    }
    
    if args.command in commands:
        commands[args.command](args)

if __name__ == "__main__":
    main()
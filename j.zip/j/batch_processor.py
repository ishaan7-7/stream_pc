import sys
import time
import logging
import hashlib
from logging.handlers import RotatingFileHandler
from pathlib import Path
from collections import defaultdict

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "Shared"))

from config import (
    DATA_DIR, DATASETS, BASE_SENSORS, CHUNK_SIZE,
    NOMINAL_CAPACITY, SESSION_TOP_K, TRAIN_RATIO,
    CAP_CLIP_MIN, CAP_CLIP_MAX,
    LOG_DIR, LOG_FORMAT, LOG_DATE_FMT,
    CAPACITY_SOURCE, PRESENTATION_DB_PATH,
)
from state_store import StateStore
from model_loader import load_model, load_calibration, get_device
from feature_extractor import (
    extract_features, validate_feature_shape,
    build_meta_tensor_values, denormalize_capacity,
)
from analytics import GoldStateManager
from parquet_reader import build_file_index
from schemas import SessionCompleted, utc_now_iso

import pyarrow.parquet as pq
import pandas as pd
import math

logging.basicConfig(
    level   = logging.INFO,
    format  = LOG_FORMAT,
    datefmt = LOG_DATE_FMT,
    handlers=[
        logging.StreamHandler(sys.stdout),
        RotatingFileHandler(
            LOG_DIR / "batch.log",
            maxBytes  = 10 * 1024 * 1024,
            backupCount = 2,
            encoding  = "utf-8",
        ),
    ],
)
log = logging.getLogger("batch")


def _session_event_id(veh_key: str, charge_segment: int) -> str:
    key = f"{veh_key}:{charge_segment}:batch"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


def load_capacity_index(capacity_path: Path) -> dict:
    log.info(f"Loading capacity index from {capacity_path}...")
    df    = pq.read_table(capacity_path).to_pandas()
    index = defaultdict(list)
    for row in df.itertuples(index=False):
        index[row.veh_key].append({
            "charge_segment":       int(row.charge_segment),
            "mileage":              float(row.mileage),
            "capacity_pred_smooth": float(row.capacity_pred_smooth),
            "capacity_true":        float(row.capacity_true) if pd.notna(row.capacity_true) else None,
        })
    for vid in index:
        index[vid].sort(key=lambda x: x["charge_segment"])
    log.info(f"  {sum(len(v) for v in index.values()):,} sessions across {len(index):,} vehicles")
    return dict(index)


def load_vehicle_steps_batched(
    veh_key:    str,
    sessions:   list[dict],
    file_index: dict,
) -> dict[int, np.ndarray]:
    parts = veh_key.split(":")
    if len(parts) != 2:
        return {}
    dataset_name, car_id_str = parts
    car_id = int(car_id_str)

    file_groups: dict[str, list] = defaultdict(list)
    for sess in sessions:
        seg   = sess["charge_segment"]
        key   = (dataset_name, car_id, seg)
        entry = file_index.get(key)
        if entry:
            _, ts_path, snippet_id = entry
            file_groups[str(ts_path)].append((ts_path, snippet_id, seg))

    result: dict[int, np.ndarray] = {}
    for _, group in file_groups.items():
        ts_path     = group[0][0]
        snippet_ids = [sid for _, sid, _ in group]
        try:
            df = pq.read_table(
                ts_path,
                filters=[("snippet_id", "in", snippet_ids)],
                columns=["snippet_id", "step_index"] + BASE_SENSORS,
            ).to_pandas()
        except Exception as e:
            log.warning(f"Parquet read error for {veh_key}: {e}")
            continue

        for _, snippet_id, seg in group:
            rows = df[df["snippet_id"] == snippet_id].sort_values("step_index")
            if len(rows) < CHUNK_SIZE:
                continue
            result[seg] = rows[BASE_SENSORS].values[:CHUNK_SIZE].astype(np.float32)

    return result


def build_vehicle_meta(data_dir: Path, datasets: list) -> dict:
    meta_base    = data_dir / "metadata"
    fault_labels = {}
    split_map    = {}

    for ds in datasets:
        car_ids_seen = set()
        for meta_path in sorted((meta_base / f"dataset={ds}").glob("part-*.parquet")):
            try:
                tbl = pq.read_table(meta_path, columns=["car_id", "fault_label"]).to_pandas()
                for row in tbl.itertuples(index=False):
                    vk = f"{ds}:{int(row.car_id)}"
                    fault_labels[vk] = int(row.fault_label)
                    car_ids_seen.add(int(row.car_id))
            except Exception:
                continue

        sorted_cars = sorted(car_ids_seen)
        n_train     = math.ceil(len(sorted_cars) * TRAIN_RATIO)
        train_cars  = set(sorted_cars[:n_train])
        for cid in sorted_cars:
            vk = f"{ds}:{cid}"
            split_map[vk] = "train" if cid in train_cars else "val"

    return fault_labels, split_map


def run_batch():
    log.info("=" * 60)
    log.info("  Battery Health — Batch Processor")
    log.info("  Building presentation.db from raw parquet data")
    log.info("=" * 60)

    t_start = time.monotonic()

    device = get_device()
    log.info(f"Compute device: {device}")

    cal = load_calibration()
    model, threshold, session_top_k, _ = load_model(device=device, calibration=cal)
    model.eval()
    log.info(f"Model loaded | threshold={threshold:.4f} | top_k={session_top_k}")

    capacity_index = load_capacity_index(CAPACITY_SOURCE)

    log.info("Building parquet file index...")
    file_index = build_file_index(DATA_DIR, DATASETS)
    log.info(f"  {len(file_index):,} entries")

    log.info("Loading vehicle metadata...")
    fault_labels, split_map = build_vehicle_meta(DATA_DIR, DATASETS)

    store = StateStore(db_path=PRESENTATION_DB_PATH)
    store.init()
    log.info(f"Presentation DB: {PRESENTATION_DB_PATH}")

    vehicle_records = []
    for veh_key, sessions in capacity_index.items():
        ds = veh_key.split(":")[0]
        vehicle_records.append({
            "vehicle_id":   veh_key,
            "dataset_name": ds,
            "car_id":       int(veh_key.split(":")[1]),
            "fault_label":  fault_labels.get(veh_key, 0),
            "split":        split_map.get(veh_key, "train"),
            "sessions":     sessions,
        })

    store.seed_vehicle_registry(vehicle_records)
    log.info(f"Seeded {len(vehicle_records):,} vehicles with nominal defaults")

    gold_mgr         = GoldStateManager()
    total_vehicles   = len(capacity_index)
    total_sessions   = 0
    skipped_sessions = 0

    for v_idx, (veh_key, sessions) in enumerate(capacity_index.items(), 1):
        if v_idx % 50 == 0 or v_idx == total_vehicles:
            elapsed = time.monotonic() - t_start
            log.info(
                f"  [{v_idx}/{total_vehicles}] "
                f"sessions_so_far={total_sessions:,} "
                f"elapsed={elapsed:.0f}s"
            )

        ds, car_id_str = veh_key.split(":")
        car_id         = int(car_id_str)
        fault_label    = fault_labels.get(veh_key, 0)

        steps_by_seg = load_vehicle_steps_batched(veh_key, sessions, file_index)
        if not steps_by_seg:
            continue

        gold_state = gold_mgr.get_or_create(
            vehicle_id   = veh_key,
            dataset_name = ds,
            car_id       = car_id,
            fault_label  = fault_label,
            split        = split_map.get(veh_key, "train"),
        )

        now = utc_now_iso()

        for sess in sessions:
            seg   = sess["charge_segment"]
            steps = steps_by_seg.get(seg)

            if steps is None:
                skipped_sessions += 1
                continue

            features = extract_features(steps)
            if not validate_feature_shape(features):
                skipped_sessions += 1
                continue

            ts_x   = torch.tensor(features, dtype=torch.float32).unsqueeze(0).to(device)
            m_val  = build_meta_tensor_values(sess["mileage"], float(seg))
            meta_x = torch.tensor([m_val], dtype=torch.float32).to(device)

            with torch.no_grad():
                fault_logit, cap_est = model(ts_x, meta_x)

            fault_prob = float(torch.sigmoid(fault_logit).item())
            cap_ah     = float(np.clip(
                denormalize_capacity(cap_est.item()), CAP_CLIP_MIN, CAP_CLIP_MAX
            ))

            from types import SimpleNamespace
            chunk = SimpleNamespace(
                session_id        = seg,
                fault_probability = fault_prob,
                capacity_estimate = cap_ah,
                mileage           = sess["mileage"],
                session_score     = fault_prob,
            )
            gold_state.apply_chunk(chunk, threshold)

            session_completed = SessionCompleted(
                event_id             = _session_event_id(veh_key, seg),
                vehicle_id           = veh_key,
                session_id           = seg,
                dataset_name         = ds,
                car_id               = car_id,
                fault_label          = fault_label,
                final_session_score  = round(fault_prob, 6),
                alarm_triggered      = fault_prob >= threshold,
                n_chunks_scored      = 1,
                capacity_pred_smooth = round(sess["capacity_pred_smooth"], 4),
                capacity_true        = sess.get("capacity_true"),
                mileage              = round(sess["mileage"], 2),
                session_start_ts     = now,
                session_end_ts       = now,
                bronze_latency_ms    = 0.0,
                silver_latency_ms    = 0.0,
            )

            gold_state.apply_session(session_completed, threshold)

            try:
                store.insert_session(session_completed, first_event_id=session_completed.event_id)
            except Exception:
                pass

            gold_update = gold_state.to_gold_update(
                threshold       = threshold,
                session_top_k   = session_top_k,
                gold_latency_ms = 0.0,
            )
            try:
                store.upsert_vehicle_state(gold_update)
                store.set_vehicle_status(veh_key, "idle")
            except Exception:
                pass

            total_sessions += 1

    log.info(f"All vehicles processed — {total_sessions:,} sessions written, {skipped_sessions:,} skipped")

    log.info("Updating risk ranks...")
    store.update_risk_ranks()

    log.info("Running projection service...")
    sys.path.insert(0, str(Path(__file__).parent.parent / "06_projection"))
    from projection_service import run_once as run_projections
    processed, skipped = run_projections(store)
    log.info(f"  Projections — updated={processed} skipped={skipped}")

    elapsed = time.monotonic() - t_start

    alarms  = len(store.get_active_alarms())
    summary = store.get_fleet_summary()
    log.info("=" * 60)
    log.info(f"  Batch complete in {elapsed:.0f}s ({elapsed/60:.1f} min)")
    log.info(f"  Vehicles  : {summary['total_vehicles']:,}")
    log.info(f"  Sessions  : {total_sessions:,}")
    log.info(f"  Alarms    : {alarms}")
    log.info(f"  Avg SOH   : {summary.get('avg_soh_pct', 0):.1f}%")
    log.info(f"  DB path   : {PRESENTATION_DB_PATH}")
    log.info("=" * 60)

    store.close()


if __name__ == "__main__":
    run_batch()
